# Generalized-hough-transform-with-rotation
Generalized hough transform with template rotation
Given a template as binary edge image the function finds the object that match the template in the image. The orientation of the object can be different from that of the template. Scanning is done by rotating the template and matching it to the image in various of angles, the best match is returned. Matching the template generalized hough transform. See the ReadRe file in the code zip file for more details.
